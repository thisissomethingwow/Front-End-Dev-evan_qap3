/***Question 1***/
class User{
    constructor(n,a){
        this.name = n;
        this.age = a;
    }
}
function makeObj(){
    var name = document.querySelector("#name").value;
    var age = document.querySelector("#age").value;
    user = new User(name,age);   
}

function displayObj(){
    let show = document.querySelector("#user-details")
    show.innerHTML = `<p>Name: ${user.name}<br>Age: ${user.age}</p>` 
}

/***Question 2***/
document.querySelector("#btnq2").addEventListener("click",loadData)

function loadData(){
    const xhr = new XMLHttpRequest();
    xhr.open('GET','./data/user.json')
    xhr.onload=function(){
        if(this.status===200){
            const user = JSON.parse(this.responseText);
            const output = `<ul><li>Name: ${user.name}</li> <li>Company: ${user.company}</li></ul>`
            document.querySelector("#q2").innerHTML=output
        }
    }
    xhr.send()
}




/*** Question 3***/

document.querySelector("#btnq3").addEventListener("click",loadAPI)
function loadAPI(){
    fetch("https://jsonplaceholder.typicode.com/todos").then((res)=>{
        return res.json();
    }).then((data)=>{
        let output=""
        data.forEach((todo)=>{
            output+=`<div class="todo"><ul><li>${todo.title}</li></ul></div>`
        });
        document.querySelector("#q3").innerHTML=output
    })
}

